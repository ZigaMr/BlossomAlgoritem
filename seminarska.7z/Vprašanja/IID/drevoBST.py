from dvojisko_drevo import Drevo
from iskalno_drevo import *

def je_iskalno(drevo):
    ''' Vrne ali je dvojiško drevo iskalno.'''
    return je_iskalno_drevo_rek(drevo, mini=float('-inf'), maxi=float('inf'))


def je_iskalno_drevo_rek(drevo, mini, maxi):
    '''mini < drevo.podatek < maxi'''
    if drevo.prazno:
        return True
    
    if drevo.podatek < mini or drevo.podatek > maxi:
        return False

    return (je_iskalno_drevo_rek(drevo.levo, mini, drevo.podatek-1) and
          je_iskalno_drevo_rek(drevo.desno, drevo.podatek+1, maxi))


def vmesni_pregled(drevo):
    '''vmesni pregled dreves'''
    if not drevo.prazno:
        for levi in vmesni_pregled(drevo.levo):
            yield levi   
        yield drevo.podatek
        for desni in vmesni_pregled(drevo.desno):
            yield desni


def je_iskalno_vmesni(drevo):
    '''z vmesnim pregledom preveri ali je drevo iskalno'''
    prejsni = float('-inf')
    for podatek in vmesni_pregled(drevo):
        if prejsni >= podatek:
            return False
        prejsni = podatek
    return True

